/************************** (C) COPYRIGHT 2010 STMicroelectronics ********************
* THE PRESENT FIRMWARE/SOFTWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
**************************************************************************************/

#ifndef CCOMPORT_H
#define CCOMPORT_H

#include <QObject>
#include <QSerialPort>


class CComPort : public QObject
{
    Q_OBJECT

public:
    static const int FBufferMaxLen=2048;

private:
    QSerialPort *serialPort;
    unsigned char FEndOfFrame;
    int FBufferLen;
    unsigned char FBuffer[FBufferMaxLen];
    quint32 BaudRate;

public:
    explicit CComPort(QObject *parent = 0);
    ~CComPort();

    int Open(int PortSpeed = 9600);
    int Opened();
#ifdef _WIN32
    int IsRS232();
#endif
    int Close();
    void SetPortNumber(int Value);
    void SetPortSpeed(int Value);
    void SetEndOfFrame(unsigned char  Value);
    int Write(unsigned char *Buffer, int NumToWrite, int *NumWritten);
    int ReadFrame(unsigned char *Buffer, int MaxDim, int *FrameAvailable, double MaxWait);

};

#endif

