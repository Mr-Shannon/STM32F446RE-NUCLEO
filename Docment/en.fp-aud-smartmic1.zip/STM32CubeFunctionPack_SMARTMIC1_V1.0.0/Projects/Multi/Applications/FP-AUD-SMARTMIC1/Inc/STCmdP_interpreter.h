/**
******************************************************************************
* @file    STCmdP_interpreter.h
* @author  Central Labs
* @version V1.0.0
* @date    10-March-2017
* @brief   This file contains definitions for STCmdP_interpreter.h file.
******************************************************************************
* @attention
*
* <h2><center>&copy; COPYRIGHT(c) 2014 STMicroelectronics</center></h2>
*
* Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
* You may not use this file except in compliance with the License.
* You may obtain a copy of the License at:
*
*        http://www.st.com/software_license_agreement_liberty_v2
*
* Unless required by applicable law or agreed to in writing, software 
* distributed under the License is distributed on an "AS IS" BASIS, 
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*
******************************************************************************
*/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STCMDP_INTERPRETER_H
#define __STCMDP_INTERPRETER_H

/* Includes ------------------------------------------------------------------*/

#include "audio_application.h"
#include "Audio_SerialCmd_Handlers.h"
#include "STCmdP_Command.h"

/** @defgroup SMARTMIC1 
* @{
*/

/** @defgroup SMARTMIC1_COMMUNICATION 
* @{
*/

/** @addtogroup SMARTMIC1_COMMUNICATION_STCmdPInterpreter
* @{
*/

/** @addtogroup SMARTMIC1_COMMUNICATION_STCmdPInterpreter_Exported_Define
* @{
*/
/* Exported define -----------------------------------------------------------*/
#define SENDER_UART     		0x01
#define SENDER_USB		        0x02
#define SENDER_SPI		        0x03
#define SENDER_BLE                      0x04
#define DEV_ADDR                        50
/**
* @}
*/ 

/** @addtogroup SMARTMIC1_COMMUNICATION_STCmdPInterpreter_Exported_Variables
* @{
*/
/* Exported variables --------------------------------------------------------*/
extern volatile uint8_t SenderInterface;
extern volatile uint8_t DataStreamingDest;
/**
* @}
*/ 

/** @addtogroup SMARTMIC1_COMMUNICATION_STCmdPInterpreter_Exported_Functions_Prototypes
* @{
*/
/* Exported functions prototypes ---------------------------------------------*/
int HandleMSG(TMsg *Msg);
void BUILD_REPLY_HEADER(TMsg *Msg);
void BUILD_NACK_HEADER(TMsg *Msg);
int Generic_ReceivedMSG(TMsg *Msg);
void Generic_SendMsg(TMsg *Msg);

/**
* @}
*/ 

/**
* @}
*/ 

/**
* @}
*/ 

/**
* @}
*/ 




#endif /* __STCMDP_INTERPRETER_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
