/**
  ******************************************************************************
  * @file    usb_protocol_interface.h
  * @author  Central Labs
  * @version V0.0.1
  * @date    15-Feb-2015
  * @brief   header for usb_protocol_interface.c.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2014 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */


/* Define to prevent recursive inclusion ------------------------------------ */
#ifndef __USB_PROTOCOL_INTERFACE__H
#define __USB_PROTOCOL_INTERFACE__H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "STCmdP.h"

/** @addtogroup STEVAL-IDI001V1_Applications
* @{
*/

/** @addtogroup Data_Logger
* @{
*/

void USB_SendMsg(TMsg *Msg);
int USB_ReceivedMSG(TMsg *Msg);

/**
  * @}
  */

/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /* __USB_PROTOCOL_INTERFACE__H */


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
