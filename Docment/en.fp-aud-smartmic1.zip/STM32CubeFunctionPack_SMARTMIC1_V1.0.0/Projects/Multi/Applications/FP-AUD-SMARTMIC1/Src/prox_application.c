/**
******************************************************************************
* @file    prox_application.c 
* @author  Central Labs
* @version V1.0.0
* @date    10-March-2017
* @brief   proximity sensors related functions. 
*******************************************************************************
* @attention
*
* <h2><center>&copy; COPYRIGHT(c) 2014 STMicroelectronics</center></h2>
*
* Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
* You may not use this file except in compliance with the License.
* You may obtain a copy of the License at:
*
*        http://www.st.com/software_license_agreement_liberty_v2
*
* Redistribution and use in source and binary forms, with or without modification,
* are permitted provided that the following conditions are met:
*   1. Redistributions of source code must retain the above copyright notice,
*      this list of conditions and the following disclaimer.
*   2. Redistributions in binary form must reproduce the above copyright notice,
*      this list of conditions and the following disclaimer in the documentation
*      and/or other materials provided with the distribution.
*   3. Neither the name of STMicroelectronics nor the names of its contributors
*      may be used to endorse or promote products derived from this software
*      without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
********************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include "prox_application.h"

/** @defgroup SMARTMIC1 
* @{
*/

/** @defgroup SMARTMIC1_PROX
* @{
*/


/** @defgroup SMARTMIC1_PROX_Private_Function_Prototypes 
* @{
*/


/**
* @}
*/

/** @defgroup SMARTMIC1_PROX_Exported_Variables 
* @{
*/
/**
* @}
*/

/** @defgroup SMARTMIC1_PROX_Private_Variables 
* @{
*/

static void *VL53L0X_0_handler = NULL;
static void *VL53L0X_1_handler = NULL;
static Gesture_DIRSWIPE_1_Data_t gestureDirSwipeData;
extern AudioStatus_t UserAudioStatus;

uint16_t fault_counter = 0;

/** @defgroup SMARTMIC1_PROX_Exported_Function 
* @{
*/

/**
* @brief  Initialize TOF sensors
* @param  none
* @retval None
*/
void TOF_Init(void)
{


  if(BSP_PROX_Init( VL53L0X_0, &VL53L0X_0_handler)!= COMPONENT_OK)
  {
    return;
  }
  
  if(BSP_PROX_Init( VL53L0X_1, &VL53L0X_1_handler)!= COMPONENT_OK)
  {
    return;
  }
  
    
  UserAudioStatus.GeneralStatus.AvailableModules += ALGO_ACTIVATION_TOF;
  AudioStatus_t *InternalStatus = GetAudioStatusInternal();
  InternalStatus->GeneralStatus.AvailableModules = UserAudioStatus.GeneralStatus.AvailableModules;
  
  BSP_PROX_Sensor_Enable(VL53L0X_0_handler);
  BSP_PROX_Sensor_Enable(VL53L0X_1_handler);
  
  /* Initialize directional swipes recognition : swipe detected below 250 mm, no max speed, min duration is 0.5 sec for a swipe and hand must cover both devices */
  tof_gestures_initDIRSWIPE_1(150, 0, 500, true, &gestureDirSwipeData);  
  
  BSP_PROX_Set_DeviceMode(VL53L0X_0_handler, CONTINUOUS);
  BSP_PROX_Set_DeviceMode(VL53L0X_1_handler, CONTINUOUS);    
  
  BSP_PROX_Set_RangingProfile(VL53L0X_0_handler, VL53L0X_PROFILE_HIGH_SPEED);
  BSP_PROX_Set_RangingProfile(VL53L0X_1_handler, VL53L0X_PROFILE_HIGH_SPEED);  
}


/**
* @brief  Periodic TOF processing
* @param  none
* @retval None
*/
void PeriodicTOF(void)
{
  static uint8_t readPROX = START_M;
  
  static uint8_t range_statusL = 0;
  static uint8_t range_statusR = 0;
  uint8_t NewDataReady_0 = 0;
  uint8_t NewDataReady_1 = 0;
  uint8_t complete_Measurement =0;
  int gesture_code;
  int leakyR = 0;
  int leakyL = 0;
  int32_t leftRange, rightRange;
  uint8_t Volume;
  float used_range = 0.0f;
  uint16_t range_1 = 0;
  uint16_t range = 0;

  /* if proximity sensing is enabled*/
  if((UserAudioStatus.BeamStatus.Reserved[0] || UserAudioStatus.GeneralStatus.Reserved[0]))
  {
    //read data
    switch(readPROX)
    {
    case START_M:
      BSP_PROX_Start_Measurement(VL53L0X_0_handler);
      BSP_PROX_Start_Measurement(VL53L0X_1_handler);
      
      readPROX= WAIT_M;
      break;
    case WAIT_M:
      if(NewDataReady_0 ==0)
      {
        BSP_PROX_Get_Measurement_DataReady( VL53L0X_0_handler, &NewDataReady_0);
      }
      if(NewDataReady_1 ==0)
      {
        BSP_PROX_Get_Measurement_DataReady( VL53L0X_1_handler, &NewDataReady_1);
      }
      
      if(NewDataReady_0 !=0 && NewDataReady_1 !=0)
      {
        readPROX= GET_M;
      } 
      break;
      
    case GET_M:
      BSP_PROX_Get_Range( VL53L0X_0_handler, (uint16_t *)&range );
      BSP_PROX_Get_Range( VL53L0X_1_handler, (uint16_t *)&range_1 );
      
      readPROX=START_M;
      complete_Measurement=1;
      NewDataReady_0 = 0;
      NewDataReady_1 = 0;
      break;
    default:
      while(1);
    }
    
    //process data
    if(complete_Measurement)
    {
      /*Gesture Detect on*/
      if(UserAudioStatus.BeamStatus.Reserved[0])
      {
        
        BSP_PROX_Get_RangeStatus(VL53L0X_0_handler, &range_statusL );
        BSP_PROX_Get_LeakyRange( VL53L0X_0_handler, &leakyL );
        
        BSP_PROX_Get_RangeStatus(VL53L0X_1_handler, &range_statusR );
        BSP_PROX_Get_LeakyRange( VL53L0X_1_handler, &leakyR );
        
        leftRange = (range_statusL == 0) ? leakyL : 1200;
        rightRange = (range_statusR == 0) ? leakyR : 1200;
        
        gesture_code = tof_gestures_detectDIRSWIPE_1(leftRange, rightRange, &gestureDirSwipeData);
        
        AudioStatus_t *InternalStatus = GetAudioStatusInternal();
        if(gesture_code == GESTURES_SWIPE_LEFT_RIGHT)
        {
          InternalStatus->BeamStatus.Direction = 7;
          UserAudioStatus.BeamStatus.Direction = 7;
        }
        else if(gesture_code == GESTURES_SWIPE_RIGHT_LEFT)
        {    
          InternalStatus->BeamStatus.Direction = 3;
          UserAudioStatus.BeamStatus.Direction = 3;
        }
        BeamDirectionSetup( UserAudioStatus.BeamStatus.Direction);              
      } 
      
      /*Volume Gesture on*/
      if(UserAudioStatus.GeneralStatus.Reserved[0])
      {
        AudioStatus_t *InternalStatus = GetAudioStatusInternal();
        int temp = abs((int)range - (int)range_1);
        
        if (temp < 100)
        {
          used_range = (float)range;
          if(used_range > 500.0f)
          {
            used_range = 500.0f;
          }
          Volume = (uint8_t)(127.0f * used_range / 500.0f);
          
          UserAudioStatus.GeneralStatus.Reserved[1] = (uint32_t)(Volume);
          InternalStatus->GeneralStatus.Reserved[1] = UserAudioStatus.GeneralStatus.Reserved[1];        
          UserAudioStatus.GeneralStatus.Volume = UserAudioStatus.GeneralStatus.Reserved[1];
          InternalStatus->GeneralStatus.Volume = UserAudioStatus.GeneralStatus.Reserved[1];
          
          BSP_AUDIO_IN_SetVolume(Volume);
        }
        
      }
      complete_Measurement = 0;       
    }
  }
}




/** @defgroup SMARTMIC1_PROX_Private_Function_Prototypes 
* @{
*/


/**
* @}
*/

/**
* @}
*/

/**
* @}
*/

/**
* @}
*/

/**
* @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
