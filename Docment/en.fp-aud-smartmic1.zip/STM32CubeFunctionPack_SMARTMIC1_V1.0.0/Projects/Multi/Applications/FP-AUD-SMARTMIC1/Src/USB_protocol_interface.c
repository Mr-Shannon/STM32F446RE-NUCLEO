/**
  ******************************************************************************
  * @file    usb_protocol_interface.c
  * @author  Central Labs
  * @version V1.0.0
  * @date    15-Feb-2015
  * @brief   This file contains the functions used for received and send message
  *          via USB
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2014 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/*Include --------------------------------------------------------------------*/
#include "usb_protocol_interface.h"
#include "STCmdP.h"
#include "usbd_audio_cdc_interface.h"


/** @addtogroup STEVAL-IDI001V1_Applications
* @{
*/

/** @addtogroup Data_Logger
* @{
*/

/** @defgroup USB_PROTOCOL_INTERFACE
* @{
*/

/** @defgroup USB_PROTOCOL_INTERFACE_Private_Variables
* @{
*/
/* Private variables ---------------------------------------------------------*/
uint16_t USB_StartOfMsg_idx = 0;
uint16_t USB_LastByteMsg_idx = 0;
uint16_t USB_NewByte_idx = 0;

uint8_t  My_Buffer[2 * TMsg_MaxLen];
/**
  * @}
  */

/** @defgroup USB_PROTOCOL_INTERFACE_Exported_Functions
* @{
*/
/**
  * @brief  Send a Msg via USB
  * @param  Msg pointer to the msg
  * @retval None
  */
void USB_SendMsg(TMsg *Msg)
{
  uint16_t CountOut;
  
  CountOut = STCmdP_Prepare_Msg((uint8_t*)My_Buffer, Msg);
  
  CDC_Fill_Buffer((uint8_t*)My_Buffer, CountOut);
}

/**
  * @brief  Check if a message is received via USB.
  * @param  Msg pointer to the msg
  * @retval None
  */
int USB_ReceivedMSG(TMsg *Msg)
{
  uint8_t *USB_RxBuffer;
  
  if (USB_NewByte_idx != USB_CheckForNewData())
  {
    USB_NewByte_idx = USB_CheckForNewData();
    USB_RxBuffer = USB_GetRxBuffer();
    
    if(STCmdP_Extract_Msg(USB_RxBuffer, USB_StartOfMsg_idx, USB_NewByte_idx, USB_RxBufferDim, Msg) != 0)
    {
      USB_StartOfMsg_idx = USB_NewByte_idx;
      return 1;
    }
  }
  return 0;
}


/**
  * @brief  Check if a message is received via USB.
  * @param  Msg pointer to the msg
  * @retval None
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
