/**
******************************************************************************
* @file    main.c
* @author  Central Labs
* @version V1.0.0
* @date    10-March-2017
* @brief   SMARTMIC1 main file.
******************************************************************************
* @attention
*
* <h2><center>&copy; COPYRIGHT(c) 2016 STMicroelectronics</center></h2>
*
* Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
* You may not use this file except in compliance with the License.
* You may obtain a copy of the License at:
*
*        http://www.st.com/software_license_agreement_liberty_v2
*
* Unless required by applicable law or agreed to in writing, software 
* distributed under the License is distributed on an "AS IS" BASIS, 
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*
******************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include "main.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
static void SystemClock_Config(void);
USBD_HandleTypeDef hUSBDDevice;


/**
* @brief  Main program
* @param  None
* @retval None
*/

int main(void)
{
  /* STM32F4xx HAL library initialization:
  - Configure the Flash prefetch, instruction and Data caches
  - Configure the Systick to generate an interrupt each 1 msec
  - Set NVIC Group Priority to 4
  - Global MSP (MCU Support Package) initialization
  */    
  HAL_Init();
  /* Configure the system clock to 180 MHz */
  SystemClock_Config();  
  /* Message used for command exchange */  
  TMsg Msg;
  /* Initialize song fragment structures */
  Songs_Init();  
  /*Initialize audio status*/
  AudioStatus_Init();    
  /*Initialize audio dewvices*/
  AudioDevices_Init();  
  
#ifdef STM32_BLUECOIN
  /* Initialize ewok */ 
  TOF_Init();
  /* Initialize LEDs */
  BSP_LED_Init(LED1);
  BSP_LED_Init(LED2);
  BSP_LED_Init(LED3);
  BSP_LED_Init(LED4);
  BSP_LED_Init(LED5);
  BSP_LED_Init(LED6);
  BSP_LED_Init(LED7);
  BSP_LED_Init(LED8);     
#endif
  
#ifdef USE_COMPOSITE_VCP_AUDIO  
  /*Init Descriptor for the current setup*/
  USBD_AUDIO_CDC_Init_Microphone_Descriptor(AUDIO_IN_SAMPLING_FREQUENCY, AUDIO_CHANNELS_OUT);
  /* Init Device Library */
  USBD_Init(&hUSBDDevice, &AUDIO_Desc, 0);
  /* Add Supported Class */
  USBD_RegisterClass(&hUSBDDevice, &USBD_AUDIO_CDC);
  /* Add Interface callbacks for AUDIO and CDC Class */
  USBD_AUDIO_CDC_RegisterInterface(&hUSBDDevice, &USBD_AUDIO_CDC_fops);  
#else  
  /* Initialize UART */
  BSP_USART_Init();
  /* Initialize USB descriptor basing on channels number and sampling frequency */
  USBD_AUDIO_Init_Microphone_Descriptor(&hUSBDDevice, AUDIO_IN_SAMPLING_FREQUENCY, AUDIO_CHANNELS_OUT);
  /* Init Device Library */
  USBD_Init(&hUSBDDevice, &AUDIO_Desc, 0);
  /* Add Supported Class */
  USBD_RegisterClass(&hUSBDDevice, &USBD_AUDIO);
  /* Add Interface callbacks for AUDIO Class */  
  USBD_AUDIO_RegisterInterface(&hUSBDDevice, &USBD_AUDIO_fops);      
  /* Start Device Process */
  USBD_Start(&hUSBDDevice);  
#endif
  
  /* Start Device Process */
  USBD_Start(&hUSBDDevice);
  HAL_Delay(500);  
  
  /*Init SW interrupts*/
  SW_IRQ_Tasks_Init();
  /*Initialize audio application depending on the status (Algo enabling, mem allocation...) */
  InitializeApplication();
  /*Start Acquisition*/
  StartMicAcquisition();
  
  while(1)
  {  
    /* Message exchange manager */
    if (Generic_ReceivedMSG((TMsg*)&Msg))
    {
      if (Msg.Data[0] == 0x32)
      {
        if (HandleMSG((TMsg*) &Msg))
        {
          Generic_SendMsg(&Msg); 
        }
      }
      /* Manage status changes */
    }
    PeriodicAudioStatusManager();
    
#ifdef STM32_BLUECOIN
    
    PeriodicTOF();   
    
#endif
  }  
}


/**
* @brief  System Clock Configuration
*         The system Clock is configured as follow : 
*            System Clock source            = PLL (HSE)
*            SYSCLK(Hz)                     = 168000000
*            HCLK(Hz)                       = 168000000
*            AHB Prescaler                  = 1
*            APB1 Prescaler                 = 4
*            APB2 Prescaler                 = 2
*            HSE Frequency(Hz)              = 8000000
*            PLL_M                          = 8
*            PLL_N                          = 336
*            PLL_P                          = 2
*            PLL_Q                          = 7
*            VDD(V)                         = 3.3
*            Main regulator output voltage  = Scale1 mode
*            Flash Latency(WS)              = 5
*         The USB clock configuration from PLLSAI:
*            PLLSAIM                        = 8
*            PLLSAIN                        = 384
*            PLLSAIP                        = 8
* @param  None
* @retval None
*/
static void SystemClock_Config(void)
{
  
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct;
  
  /**Configure the main internal regulator output voltage 
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  
  /**Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
#ifdef USE_STM32F4XX_NUCLEO
  RCC_OscInitStruct.PLL.PLLM = 8;
#elif defined (STM32_BLUECOIN)
  RCC_OscInitStruct.PLL.PLLM = 16;
#endif
  RCC_OscInitStruct.PLL.PLLN = 360;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 8;
  RCC_OscInitStruct.PLL.PLLR = 6;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);
  
  /**Activate the Over-Drive mode 
  */
  HAL_PWREx_EnableOverDrive();
  
  /**Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
    |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
  
  
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2S_APB1|RCC_PERIPHCLK_SAI1
    |RCC_PERIPHCLK_CLK48;
  PeriphClkInitStruct.PLLI2S.PLLI2SN = 344;
  PeriphClkInitStruct.PLLI2S.PLLI2SP = RCC_PLLI2SP_DIV2;
#ifdef USE_STM32F4XX_NUCLEO
  PeriphClkInitStruct.PLLI2S.PLLI2SM = 8;
#elif defined (STM32_BLUECOIN)
  PeriphClkInitStruct.PLLI2S.PLLI2SM = 16;
#endif
  PeriphClkInitStruct.PLLI2S.PLLI2SR = 7;
  PeriphClkInitStruct.PLLI2S.PLLI2SQ = 7;
#ifdef USE_STM32F4XX_NUCLEO
  PeriphClkInitStruct.PLLSAI.PLLSAIM = 8;
#elif defined (STM32_BLUECOIN)
  PeriphClkInitStruct.PLLSAI.PLLSAIM = 16;
#endif
  
  PeriphClkInitStruct.PLLSAI.PLLSAIN = 384;
  PeriphClkInitStruct.PLLSAI.PLLSAIQ = 7;
  PeriphClkInitStruct.PLLSAI.PLLSAIP = RCC_PLLSAIP_DIV8;
  PeriphClkInitStruct.PLLI2SDivQ = 1;
  PeriphClkInitStruct.PLLSAIDivQ = 1;
  PeriphClkInitStruct.Clk48ClockSelection = RCC_CLK48CLKSOURCE_PLLSAIP;
  PeriphClkInitStruct.Sai1ClockSelection = RCC_SAI1CLKSOURCE_PLLI2S;
  PeriphClkInitStruct.I2sApb1ClockSelection = RCC_I2SAPB1CLKSOURCE_PLLI2S;
  HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct);
  
  /**Configure the Systick interrupt time 
  */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);
  
  /**Configure the Systick 
  */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);
  
  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
  
}



#ifdef  USE_FULL_ASSERT
/**
* @brief  Reports the name of the source file and the source line number
*         where the assert_param error has occurred.
* @param  file: pointer to the source file name
* @param  line: assert_param error line source number
* @retval None
*/
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
  ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  
  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
