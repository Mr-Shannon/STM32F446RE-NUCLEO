/**
  @page SMARTMIC1 Smart Audio IN-OUT software expansion for STM32Cube
  
  @verbatim
  ******************** (C) COPYRIGHT 2015 STMicroelectronics *******************
  * @file    readme.txt  
  * @author  Central Labs
  * @version V2.0.0
  * @date    10-March-2017
  * @brief   Description of the SMARTMIC1 application.
  ******************************************************************************
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  @endverbatim

@par Example Description 

SMARTMIC1 provides a firmware running on STM32 which acquires audio signals 
using four digital MEMS microphones, elaborates them by means of embedded DSP 
libraries and streams the processed audio to both an USB host and a loudspeaker 
connected to the relevant expansion board.
The package includes the following acoustic libraries:
-	AcousticBF library provides an implementation for a real-time adaptive 
	beamforming algorithm: using the audio signals acquired from two digital MEMS 
	microphones, it creates a virtual directional microphone pointing to a fixed 
	direction in space.
-	AcousticEC library provides an implementation for a real-time echo 
	cancellation routine based on the well-known SPEEX implementation of the MDF 
	algorithm. 
-	AcousticSL library <provides an implementation for a real-time sound source 
	localization algorithm: using 2 or 4 signals acquired from digital MEMS 
	microphones, it can estimate the arrival direction of the audio source.

The firmware provides implementation example for STM32 NUCLEO-F446RE board  
equipped with:
-	X-NUCLEO-CCA01M1, an expansion board based on the STA350BW Sound Terminal® 
	2.1-channel high-efficiency digital audio output system.
-	X-NUCLEO-CCA02M1, an evaluation board based on digital MEMS microphones, designed 
	around STMicroelectronics MP34DT01-M digital microphones.
-	STEVAL-MKI129Vx digital microphones.

A communication infrastructure is porvided, in order to control the device status and 
setup the running algorithm from a host PC.


 After the initialization of all the required elements (microphones, audio output, 
 USB communication and streaming) digital MEMS microphone acquisition starts and 
 drives the whole application: when a millisecond of the microphones signal is made 
 available by the BSP layer, several operations are performed concurrently, 
 depending on the current status of the application. Among these we have:
-	Beam Forming
-	Source Localization
-	Acousti Echo Cancellation
-	dB SPL Estimation

Then the processed audio is streamed to 2 interfaces at the same time: 
-	 USB: the device is recognized as a standard USB stereo microphone by a host 
PC that can be used to record and save the real time audio streaming. The stereo 
track contains the processed signal (L channel) and an omnidirectional microphone 
as a reference (R channel)
-	I2S: an I2S peripheral of the MCU is connected to the STA350BW Sound Terminal® 
device mounted on the X-NUCLEO-CCA01M1 board. In this way the processed signal can 
be reproduced by a loudspeaker connected to the expansion board.

A communication infrastructure, based on the ST-LINK VCP or an ad-hoc composite Audio+VCP 
USB class, is set up in order to estabilish a link between the  system and the PC. 
This allows to control the demo at runtime (enable/disable the algorithms) and rethrieve 
the relevant data computed in the MCU, like the estimated dBSPL level or the direction 
of Arrival of the main audio source as computed by the Open.Audio libraries.

The HCLK is configured at 168 MHz for STM32F446xx Devices.

@note Care must be taken when using HAL_Delay(), this function provides accurate delay (in milliseconds)
      based on variable incremented in SysTick ISR. This implies that if HAL_Delay() is called from
      a peripheral ISR process, then the SysTick interrupt must have higher priority (numerically lower)
      than the peripheral interrupt. Otherwise the caller ISR process will be blocked.
      To change the SysTick interrupt priority you have to use HAL_NVIC_SetPriority() function.
      
@note The application needs to ensure that the SysTick time base is always set to 1 millisecond
      to have correct HAL operation.

@note The clock setting is configured to have an high product performance (high clock frequency) 
      so not optimized in term of power consumption.
	  
@par Hardware and Software environment

  - This example runs on STM32F446xx devices.
    
  - This example has been tested with STMicroelectronics STM32F4xx-Nucleo rev C
    boards and can be easily tailored to any other supported device 
    and development board.

  - For This example to work properly, a 2.2 µF Capacitor must be present on the board in slot C26.
	

@par How to use it ? 

In order to make the program work, you must do the following :
 - Open your preferred toolchain 
 - Rebuild all files and load your image into target memory
 - Run the example

 * <h3><center>&copy; COPYRIGHT STMicroelectronics</center></h3>
 */
